package com.example.mylist

class CustomClass (var item_title:String?,var item_desc:String?, var image_one:Int, var image_two:Int)